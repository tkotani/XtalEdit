See doc/index.htm 
or
http://sham.phys.sci.osaka-u.ac.jp/~kkr/XtalEdit/

