#!/usr/bin/python

#############################################################
## Main Routinue ############################################
if __name__ == '__main__':
	
	flog  = open("./result/ResultWindow.dat","w")
	flog.write("You don't give python path in your userconf File\n")
	flog.close()

