## Rasmol Configuration File #######
DefaultRangeMin=[-0.2,-0.2,-0.2]
DefaultRangeMax=[1.2,1.2,1.2]
DefaultBondMax=4.5
