import sys
sys.path.append("./UserModule/Common")
from addSite import *
from numpy import * 
EX = array((1., 0., 0.))
EY = array((0., 1., 0.)) 
EZ = array((0., 0., 1.))
Site = {}
Type = {}

Bohr_R	= 0.529177249  
PI = 3.14159265358979323846

a =   3.8348           
CV1 = a * EX
CV2 = a * EY
CV3 = a * EZ

PV1 =  CV1
PV2 =  CV2
PV3 =  CV3

addSite(Site,'LaSr','0.',0.)

addSite(Site,'Al','1/2. *CV1 +1/2. *CV2 +1/2. *CV3',1/2. *CV1 +1/2. *CV2 +1/2. *CV3)

addSite(Site,'O','+1/2. *CV2 +1/2. *CV3',+1/2. *CV2 +1/2. *CV3)
addSite(Site,'O','1/2. *CV1 +1/2. *CV3',1/2. *CV1 +1/2. *CV3)
addSite(Site,'O','1/2. *CV1 +1/2. *CV2',1/2. *CV1 +1/2. *CV2)

Type["LaSr"]={ "LMX":"2","ATOM":{ 57:"0.9", 38:"0.1"}}
Type["Al"]={ "LMX":"2","ATOM":{ 13:"1.0"}}
Type["O"]={ "LMX":"2","ATOM":{ 8:"1.0"}}
SiteNum  = len(Site)
TypeNum = len(Type)
for Mat in Site.keys():
	EMat=array([0., 0., 0.])
	try:
		Site[Mat]["PosData"]	=	Site[Mat]["PosData"]+EMat
	except:
		Site[Mat]["PosData"] = EMat
		Site[Mat]["POS"]	=	"0."
